# Prompt pour l'agent backend (Django) — Intégration CNETP

## Contexte
Le frontend (`cnetp-app.html`) est déjà terminé : SPA HTML/JS/Tailwind, responsive (desktop + mobile), PWA installable (`manifest.json`, `sw.js`, `icons/`). Il tourne actuellement en mode démo avec `mock-api.js` qui simule toutes les réponses API. Ton rôle : construire les vraies vues/endpoints Django pour qu'il tourne sans le mock.

## Fichiers fournis (à copier tels quels)
- `cnetp-app.html` → `apps/mobileapp/templates/mobileapp/cnetp-app.html`
- `manifest.json`, `sw.js`, `icons/` → même dossier de templates (chemins relatifs, ne rien renommer)
- Supprimer la ligne `<script src="mock-api.js"></script>` dans le `<head>` une fois les endpoints prêts.

## Ce qui doit exister côté Django
1. **Vue de rendu** dans `apps/mobileapp/views.py` :
   - `@login_required` + `@ensure_csrf_cookie` (le JS lit le cookie `csrftoken` via `getCookie`).
   - `render(request, 'mobileapp/cnetp-app.html')`.
2. **URL** `apps/mobileapp/urls.py` → montée sous `path('app/', include('apps.mobileapp.urls'))` dans `config/urls.py`.
3. **Endpoints REST sous `/api/v1/...`** (DRF, `SessionAuthentication`, réponses JSON same-origin — le JS utilise `credentials: 'same-origin'`, aucune config CORS nécessaire) pour couvrir les appels déjà présents dans le HTML. Grep `fetchWithTimeout\(` et `apiFetch\(` dans `cnetp-app.html` pour lister les URLs exactes appelées et leur shape de payload attendue (le mock-api.js montre le format de réponse actuel — aligne-toi sur ce contrat JSON, ne le casse pas) :
   - Normes/documents : liste, détail, historique de versions, sauvegarde de brouillon.
   - Experts & Groupes, adhésions CTM.
   - Réunions & votes (scrutins, bulletin de vote).
   - Cotisations & indemnités (module financier).
   - Notifications : liste + compteur non-lus + marquer comme lu (le badge décrémente déjà côté JS quand un item est lu).
   - Messagerie (contacts + conversations) : `/api/v1/messages/contacts/` déjà référencé.
   - Profil utilisateur (lecture + mise à jour : téléphone, spécialités, groupe, CTM sélectionnées, préférences thème/notifications).
4. Garder les noms de champs JSON identiques à ceux consommés dans le HTML (ne pas renommer côté Python sans adapter le JS) — vérifie chaque `.map`/déstructuration après un `apiFetch` pour la forme exacte attendue.

## Contraintes
- Le HTML est statique : aucune balise `{% %}` dedans. Ne pas transformer les données en templating serveur — tout passe par fetch JSON.
- `manifest.json`/`sw.js` utilisent des chemins relatifs (`./cnetp-app.html`, `./icons/...`) : les 4 éléments doivent rester au même niveau servi.
- Le Service Worker met les appels `/api/*` toujours en réseau (jamais de cache) — pas de changement requis de ton côté, juste à savoir que le offline ne concerne que le shell.

## Livrable attendu
- Endpoints fonctionnels retournant le même contrat JSON que `mock-api.js`.
- `mock-api.js` retiré du HTML une fois validé.
- Un test manuel : se connecter, ouvrir `/app/`, vérifier que chaque module (Éditeur, Historique, Experts, Réunions, Financier, Notifications, Profil, Messagerie) charge des données réelles sans erreur console.

Référence complète existante : `preview/DJANGO_INTEGRATION.md`.
