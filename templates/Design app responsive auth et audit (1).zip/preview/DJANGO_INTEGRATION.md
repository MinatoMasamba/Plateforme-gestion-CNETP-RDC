# Brancher cnetp-app.html sur le vrai backend Django

## Ce qui a été fait côté HTML
- `getCookie` / `fetchWithTimeout` / `apiFetch` ont maintenant une implémentation RÉELLE (fetch same-origin
  avec AbortController) définie juste après `mock-api.js`, sous forme de `window.X = window.X || ...`.
  Tant que `<script src="mock-api.js">` est présent, le mock gagne (démo). Il suffit de **supprimer cette
  ligne** pour que l'app appelle directement `/api/v1/...` avec la session Django réelle.
- PWA : `manifest.json`, `icons/`, `sw.js` + enregistrement du Service Worker + bouton
  "Installer l'application" (bandeau global + section Profil) ajoutés — fonctionne indépendamment du backend.

## Pour servir ce template depuis Django (app `mobileapp`)
1. Copier `cnetp-app.html`, `manifest.json`, `sw.js`, `icons/` dans
   `apps/mobileapp/templates/mobileapp/` (et un dossier `static/mobileapp/` pour les assets si vous préférez
   `{% static %}`).
2. Retirer `<script src="mock-api.js"></script>` du `<head>`.
3. Vue (`apps/mobileapp/views.py`) :
   ```python
   from django.contrib.auth.decorators import login_required
   from django.views.decorators.csrf import ensure_csrf_cookie
   from django.shortcuts import render

   @login_required
   @ensure_csrf_cookie  # garantit le cookie csrftoken lu par getCookie('csrftoken')
   def app_view(request):
       return render(request, 'mobileapp/cnetp-app.html')
   ```
4. `apps/mobileapp/urls.py` (créer si absent) + inclure dans `config/urls.py` avant `path('', include('web.urls'))` :
   ```python
   path('app/', include('apps.mobileapp.urls')),
   ```
5. Le HTML référence déjà `/api/v1/...` en URLs relatives — comme la page est servie par Django sur le même
   domaine, les appels `fetch` partiront avec le cookie de session (SessionAuthentication est déjà activée
   dans `REST_FRAMEWORK`). Rien à changer côté endpoints.
6. `manifest.json`/`sw.js` utilisent des chemins relatifs (`./cnetp-app.html`, `./icons/...`) : gardez les 4
   fichiers au même niveau dans le dossier de templates servi, ou ajustez les chemins si vous passez par
   `{% static %}`.

Pas de balises Django (`{% %}`) injectées dans le HTML : il reste un fichier statique que la vue rend tel
quel — seul `{% csrf_token %}` est optionnel si vous voulez éviter `ensure_csrf_cookie` (dans ce cas ajoutez
`{% csrf_token %}` n'importe où dans le `<body>`, invisible, Django posera le cookie automatiquement).
