(function () {
  function getCookie(name) {
    let v = null;
    if (document.cookie) {
      document.cookie.split(';').forEach(c => {
        c = c.trim();
        if (c.indexOf(name + '=') === 0) v = decodeURIComponent(c.substring(name.length + 1));
      });
    }
    return v;
  }
  window.getCookie = window.getCookie || getCookie;

  const now = new Date();
  const iso = d => d.toISOString();

  const DB = {
    ctms: [
      { id: 1, number: 1, name: 'Stabilité des sols et fondations' },
      { id: 3, number: 3, name: 'Structures et charpentes' },
      { id: 5, number: 5, name: 'Hygiène, sécurité, environnement' },
      { id: 8, number: 8, name: 'Matériaux locaux et normalisés' }
    ],
    wgs: [
      { id: 'wg-81', number: 1, name: 'Matériaux Locaux (Argiles & Terre)', ctm: { id: 8, number: 8, name: 'Matériaux locaux et normalisés' }, status: 'Actif' },
      { id: 'wg-82', number: 2, name: 'Bétons et Liants', ctm: { id: 8, number: 8, name: 'Matériaux locaux et normalisés' }, status: 'Actif' },
      { id: 'wg-12', number: 2, name: 'Stabilité des Sols', ctm: { id: 1, number: 1, name: 'Stabilité des sols et fondations' }, status: 'Rédaction' }
    ],
    experts: [
      { id: 1, user_name: 'Prof. Masamba Édouard', user: { first_name: 'Masamba', last_name: 'Édouard', email: 'masamba@cnetp.cd' }, structure_name: 'UNIKIN', status: 'ACTIVE', bank_name: 'Equity BCDC', bank_account: 'CD00 0000 1234', affectations: [{ ctm: 8, ctm_name: 'Matériaux locaux et normalisés', wg: 'wg-81', role: 'Président scientifique', is_primary_ctm: true }] },
      { id: 2, user_name: 'Ir. Chantal Mwamba', user: { first_name: 'Chantal', last_name: 'Mwamba', email: 'chantal@cnetp.cd' }, structure_name: 'OVD', status: 'ACTIVE', affectations: [{ ctm: 8, ctm_name: 'Matériaux locaux et normalisés', wg: 'wg-82', role: 'Secrétaire', is_primary_ctm: true }] },
      { id: 3, user_name: 'Arch. Sylvain Lukusa', user: { first_name: 'Sylvain', last_name: 'Lukusa', email: 'sylvain@cnetp.cd' }, structure_name: 'ONA', status: 'PENDING', affectations: [{ ctm: 1, ctm_name: 'Stabilité des sols et fondations', wg: 'wg-12', role: 'Rapporteur', is_primary_ctm: true }] }
    ],
    norms: [
      { id: 101, reference_number: 'Pr-RDC 9001', title: 'ISO 9001 — Révision RDC', status: 'En rédaction', norm_type: 'NCD', ctm: 8, ctm_name: 'Matériaux locaux et normalisés', wg: 'wg-81', description: "Norme de gestion qualité adaptée au contexte national.", latest_version: { content: "Article 1er — Champ d'application.\n\nArticle 2 — Définitions." } },
      { id: 102, reference_number: 'Pr-RDC 27001', title: 'Sécurité de l’information', status: 'En vote', norm_type: 'DIR', ctm: 8, ctm_name: 'Matériaux locaux et normalisés', wg: 'wg-82', description: "Directive sur la sécurité des systèmes d'information.", latest_version: { content: "Article 1er — Objet." } },
      { id: 103, reference_number: 'Pr-RDC 1042', title: 'Stabilité des sols argileux', status: 'Publiée', norm_type: 'NCD', ctm: 1, ctm_name: 'Stabilité des sols et fondations', wg: 'wg-12', description: "Prescriptions techniques pour fondations sur sols argileux.", latest_version: { content: "Article 1er — Portée." } }
    ],
    reunions: [
      { id: 201, titre: 'Session CTM 8 — Argiles', date: iso(now), status: 'PLANIFIEE', ordre_jour: 'Examen du projet Pr-RDC 9001' },
      { id: 202, titre: 'Concertation ITP', date: iso(new Date(now.getTime() + 7 * 864e5)), status: 'PLANIFIEE', ordre_jour: 'Coordination inter-CTM' }
    ]
  };

  const paginated = arr => ({ count: arr.length, results: arr });

  async function mockRouter(url, options) {
    const method = (options && options.method) || 'GET';
    const u = url.split('?')[0];

    if (/\/api\/v1\/ctm\/?$/.test(u)) return paginated(DB.ctms);
    if (/\/api\/v1\/wg\/?$/.test(u)) return paginated(DB.wgs);
    if (/\/api\/v1\/experts\/me\/?$/.test(u)) return DB.experts[0];
    if (/\/api\/v1\/experts\/pending-count-for-my-ctm\/?$/.test(u)) return { is_ctm_leader: true, count: DB.experts.filter(e => e.status === 'PENDING').length };
    if (/\/api\/v1\/experts\/pending-for-my-ctm\/?$/.test(u)) return DB.experts.filter(e => e.status === 'PENDING');
    if (/\/api\/v1\/experts\/[^/]+\/(admit-to-ctm|reject)\/?$/.test(u)) return { ok: true };
    if (/\/api\/v1\/experts\/[^/]+\/?$/.test(u) && method === 'PATCH') return { ok: true };
    if (/\/api\/v1\/experts\/?$/.test(u)) return paginated(DB.experts);
    if (/\/api\/v1\/norms\/[^/]+\/votes\/?$/.test(u)) return [];
    if (/\/api\/v1\/norms\/[^/]+\/versions\/?$/.test(u)) return [];
    if (/\/api\/v1\/norms\/[^/]+\/diff\/?$/.test(u)) return { diff: [] };
    if (/\/api\/v1\/norms\/[^/]+\/(create_version|vote|rollback-version)\/?$/.test(u)) return { ok: true };
    if (/\/api\/v1\/norms\/[^/]+\/pdf\/?$/.test(u)) return { ok: true };
    if (/\/api\/v1\/norms\/([^/]+)\/?$/.test(u)) {
      const id = u.match(/\/api\/v1\/norms\/([^/]+)\/?$/)[1];
      return DB.norms.find(n => String(n.id) === String(id)) || DB.norms[0];
    }
    if (/\/api\/v1\/norms\/?$/.test(u)) return paginated(DB.norms);
    if (/\/api\/v1\/reunions\/upcoming\/?$/.test(u)) return paginated(DB.reunions);
    if (/\/api\/v1\/reunions\/stats\/?$/.test(u)) return { total: DB.reunions.length };
    if (/\/api\/v1\/reunions\/[^/]+\/details\/?$/.test(u)) {
      const id = u.match(/\/api\/v1\/reunions\/([^/]+)\/details\/?$/)[1];
      const m = DB.reunions.find(r => String(r.id) === String(id)) || DB.reunions[0];
      return { ...m, presences: [], votes: [] };
    }
    if (/\/api\/v1\/reunions\/[^/]+\/(vote|close)\/?$/.test(u)) return { ok: true };
    if (/\/api\/v1\/reunions\/?$/.test(u) && method === 'POST') return { ok: true, id: 'r-' + Date.now() };
    if (/\/api\/v1\/reunions\/?$/.test(u)) return paginated(DB.reunions);
    if (/\/api\/v1\/presences\/[^/]+\/?$/.test(u)) return { ok: true };
    if (/\/api\/v1\/cotisations\/?$/.test(u)) return paginated([]);
    if (/\/api\/v1\/jetons\/?$/.test(u)) return paginated([]);
    if (/\/api\/v1\/paiements\/?$/.test(u)) return { ok: true };
    if (/\/api\/v1\/legistic-reviews\/workspace\/?$/.test(u)) return { steps: [], normes: [] };
    if (/\/api\/v1\/legistic-reviews\/legistique-workspace\/?$/.test(u)) return { reviews: [] };
    if (/\/api\/v1\/legistic-reviews\/set-step\/?$/.test(u)) return { ok: true };
    if (/\/api\/v1\/legistic-reviews\/[^/]+\/(assign-self|validate-ctc)\/?$/.test(u)) return { ok: true };
    if (/\/api\/v1\/messages\/contacts\/?$/.test(u)) return paginated([]);
    if (/\/api\/v1\/messages\/unread_count\/?$/.test(u)) return { count: 0 };
    if (/\/api\/v1\/messages\/mark_conversation_as_read\/?$/.test(u)) return { ok: true };
    if (/\/api\/v1\/messages\/?$/.test(u)) return { ok: true, id: 'msg-' + Date.now() };
    if (/\/api\/v1\/ia-agent\//.test(u)) return { advice: 'Analyse indisponible hors connexion (mode démo).' };
    if (/\/api\/v1\/auth\/me\/?$/.test(u)) return { first_name: 'Expert', last_name: 'Connecté', username: 'expert', email: 'expert@cnetp.cd' };
    if (/\/api\/v1\/auth\/profile\/?$/.test(u)) return { ok: true };

    return { results: [] };
  }

  window.fetchWithTimeout = window.fetchWithTimeout || async function (url, options = {}, timeout = 15000) {
    const data = await mockRouter(url, options);
    return { ok: true, status: 200, json: async () => data, text: async () => JSON.stringify(data) };
  };

  window.apiFetch = window.apiFetch || async function (url, options = {}) {
    const res = await window.fetchWithTimeout(url, options);
    return res.json();
  };

  window.withButtonLoading = window.withButtonLoading || async function (btn, fn, opts = {}) {
    if (btn) { btn.disabled = true; btn.classList.add('opacity-60', 'cursor-wait'); }
    try {
      return await fn();
    } catch (err) {
      console.warn('Mock action error', err);
      if (window.showAppToast) window.showAppToast(opts.errorMessage || 'Action indisponible (mode démo).', 'warning');
    } finally {
      if (btn) { btn.disabled = false; btn.classList.remove('opacity-60', 'cursor-wait'); }
    }
  };
})();
