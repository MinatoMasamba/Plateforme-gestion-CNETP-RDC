export const overviewData = {
  totalExperts: 200,
  totalNorms: 185,
  totalSCs: 8,
  currentPhase: 'Phase 2: Rédaction',
  deadline: '30 Nov 2026'
};

export const scData = [
  { id: 'SC1', name: 'Géotechnique', experts: 19, normes: 25, progress: 25, attendance: 95, documents: 6 },
  { id: 'SC2', name: 'Ouvrages d\'art', experts: 19, normes: 30, progress: 20, attendance: 90, documents: 5 },
  { id: 'SC3', name: 'Bâtiments', experts: 19, normes: 35, progress: 15, attendance: 85, documents: 4 },
  { id: 'SC4', name: 'Aéroports', experts: 19, normes: 15, progress: 30, attendance: 98, documents: 8 },
  { id: 'SC5', name: 'Routes, Fer, Ports', experts: 19, normes: 30, progress: 25, attendance: 92, documents: 7 },
  { id: 'SC6', name: 'Hydraulique', experts: 19, normes: 20, progress: 10, attendance: 88, documents: 3 },
  { id: 'SC7', name: 'Assainissement', experts: 19, normes: 15, progress: 10, attendance: 82, documents: 2 },
  { id: 'SC8', name: 'Matériaux', experts: 20, normes: 15, progress: 20, attendance: 94, documents: 5 },
];

export const expertsOrigin = [
  { name: 'Admin & Cabinets', value: 54 },
  { name: 'Offices & Agences', value: 74 },
  { name: 'Académique & Ordres Pro', value: 50 },
  { name: 'Privé & Société Civile', value: 22 },
];

export const normsStages = [
  { name: '1. Compilation', count: 120 },
  { name: '2. Analyse', count: 65 },
  { name: '3. Rédaction', count: 0 },
  { name: '4. Discussion', count: 0 },
  { name: '5. Enquête', count: 0 },
  { name: '6. Amendements', count: 0 },
  { name: '7. Homologation', count: 0 },
];

export const timelinePhases = [
  { phase: 'Phase 1', name: 'Enclenchement', dates: '01 - 15 Juin 2026', status: 'completed' },
  { phase: 'Phase 2', name: 'Rédaction', dates: '16 Juin - 31 Juil 2026', status: 'active' },
  { phase: 'Phase 3', name: 'Consolidation', dates: '01 - 20 Août 2026', status: 'pending' },
  { phase: 'Phase 4', name: 'Enquête Publique', dates: '21 Août - 20 Oct 2026', status: 'pending' },
  { phase: 'Phase 5', name: 'Sanction', dates: '21 - 31 Oct 2026', status: 'pending' },
  { phase: 'Phase 6', name: 'Homologation', dates: '01 - 30 Nov 2026', status: 'pending' },
];

export const structuresDistribution = [
  { name: 'Secrétariat Général ITP', count: 15 },
  { name: 'Cabinet du Ministre', count: 12 },
  { name: 'SG Reconstruction', count: 12 },
  { name: 'Office des Routes (OR)', count: 12 },
  { name: 'OVD', count: 12 },
  { name: 'ACGT', count: 12 },
  { name: 'Bureau Tech. Contrôle (BTC)', count: 10 },
  { name: 'FONER', count: 10 },
  { name: 'Cellule Infrastructure (CI)', count: 10 },
  { name: 'BEAU', count: 8 },
  { name: 'Académique (UNIKIN, INBTP...)', count: 20 },
  { name: 'Ordres Pro (ONIC, ONA...)', count: 22 },
  { name: 'Autres Ministères', count: 15 },
  { name: 'Société Civile & Privé', count: 14 }
];

export const expertsDirectory = [
  { id: 'Poste 1', name: 'Estimé Mukandila', role: 'Président du Comité', structure: 'Cabinet du Ministre', affectation: 'Comité de Pilotage (COPIL)', type: 'pilotage' },
  { id: 'Poste 3', name: 'Firmin Kiala', role: 'Coordonnateur Principal', structure: 'SG-ITP', affectation: 'Cellule Tech. Coord. (CTC)', type: 'ctc' },
  { id: 'Poste 4', name: 'Michel Uyumbu', role: 'Coordonnateur Adjoint', structure: 'Cabinet du Ministre', affectation: 'Cellule Tech. Coord. (CTC)', type: 'ctc' },
  { id: 'Poste 5', name: 'Willy Vale', role: 'Expert Stabilité & Érosions', structure: 'Cabinet du Ministre', affectation: 'CTM 1 / WG 1.3', type: 'ctm' },
  { id: 'Poste 30', name: 'Emmanuel Luwenga', role: 'Expert Pôle Ingénierie', structure: 'SG Reconstruction', affectation: 'Cellule Tech. Coord. (CTC)', type: 'ctc' },
  { id: 'Poste 61', name: 'Pierre Mukendi', role: 'Directeur Technique', structure: 'Office des Routes', affectation: "Collège d'Appui (Pilotage)", type: 'pilotage' },
  { id: 'Poste 62', name: 'Jean-Paul Nyembo', role: 'Ingénieur Géologue Principal', structure: 'Office des Routes', affectation: 'CTM 1 / WG 1.1', type: 'ctm' },
  { id: 'Poste 65', name: 'Azama Muzyumba', role: 'Ingénieur Principal Ponts', structure: 'Office des Routes', affectation: 'CTM 2 / WG 2.1', type: 'ctm' },
  { id: 'Poste 76', name: 'Bosco Bifulu', role: 'Spécialiste Érosions Urbaines', structure: 'OVD', affectation: 'CTM 1 / WG 1.3', type: 'ctm' },
  { id: 'Poste 90', name: 'Freddy Kazadi', role: 'Expert Modélisateur BIM', structure: 'ACGT', affectation: 'CTM 3 / WG 3.2', type: 'ctm' },
  { id: 'Poste 98', name: 'Alain Mutombo', role: 'Opérateur Saisie Principal', structure: 'BTC', affectation: 'Cellule Tech. Coord. (CTC)', type: 'ctc' },
  { id: 'Poste 129', name: 'Prof. Tshibangu', role: 'Secrétaire Permanent', structure: 'Académique', affectation: 'Comité de Pilotage (COPIL)', type: 'pilotage' },
  { id: 'Poste 131', name: 'Julie Nsoki', role: 'Urbaniste Concepteur', structure: 'BEAU', affectation: 'CTM 3 / WG 3.1', type: 'ctm' },
  { id: 'Poste 138', name: 'Marc Kabuya', role: 'Rapporteur Technique', structure: 'Ordre (ONIC)', affectation: 'Bureau CTM 1', type: 'ctm' },
  { id: 'Poste 168', name: 'Dr. Ilunga', role: 'Président Scientifique', structure: 'UNIKIN (Académique)', affectation: 'Bureau CTM 1', type: 'ctm' },
  { id: 'Poste 179', name: 'Sarah Kankolongo', role: 'Directeur Métrologie Éco.', structure: 'OCC', affectation: "Collège d'Appui (Pilotage)", type: 'pilotage' },
  { id: 'Poste 180', name: 'David Mbuyi', role: 'Expert Certification Inter.', structure: 'OCC', affectation: 'Cellule Tech. Coord. (CTC)', type: 'ctc' },
].map(exp => ({
  ...exp,
  bio: `Expert sénior spécialisé en normes de construction. Profil académique et professionnel rattaché à la structure : ${exp.structure}. Affecté à la tâche critique : ${exp.affectation}. Engage sa responsabilité technique sur la validation des normes congolaises (NNC).`,
  contributions: [
    `Rédaction et analyse des textes pour ${exp.affectation}`,
    `Participation active aux ateliers de validation de Juin 2026`,
    `Évaluation de la conformité aux standards ISO/ARSO`
  ],
  attendance: [
    { session: 'Atelier de Lancement', date: '26 Mai 2026', present: true },
    { session: 'Session de Travail #1', date: '05 Juin 2026', present: true },
    { session: 'Session de Travail #2', date: '20 Juin 2026', present: Math.random() > 0.1 } 
  ]
}));

export const expertDetails = [
  { role: 'Président COPIL', name: 'Haut Cadre Cabinet ITP', category: 'Direction', presence: '100%', contribution: 'Orientations' },
  { role: 'Coord. Principal', name: 'Directeur Normes SG-ITP', category: 'CTC', presence: '100%', contribution: 'Pilotage' },
  { role: 'Président SC1', name: 'Professeur Mécanique Sols', category: 'SC1', presence: '95%', contribution: 'Validations SC1' },
  { role: 'Président SC2', name: 'Professeur Béton Armé', category: 'SC2', presence: '90%', contribution: 'Validations SC2' },
  { role: 'Rapporteur SC5', name: 'Expert FIGT-CEICO', category: 'SC5', presence: '100%', contribution: 'Matrice SC5' },
];
