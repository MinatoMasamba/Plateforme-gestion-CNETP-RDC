import './index.css';
import { Chart, registerables } from 'chart.js';
import { createIcons, icons } from 'lucide';
import { 
  overviewData, scData, expertsOrigin, normsStages, 
  timelinePhases, structuresDistribution, expertsDirectory 
} from './data';

// Register Chart.js components
Chart.register(...registerables);

// Initialize Lucide icons
createIcons({ icons });

// Colors for charts
const pieColors = ['#2563eb', '#3b82f6', '#60a5fa', '#93c5fd', '#bfdbfe'];
const statusColors: Record<string, string> = {
  completed: 'bg-green-500',
  active: 'bg-blue-500 animate-pulse',
  pending: 'bg-gray-300'
};

document.addEventListener('DOMContentLoaded', () => {
  renderKpiCards();
  renderBarChart();
  renderPieChart();
  renderLineChart();
  renderTimeline();
  renderTable();
  renderStructuresChart();
  renderExpertsTable('all');
  setupExpertFilters();
});

function renderStructuresChart() {
  const ctx = document.getElementById('structures-bar-chart') as HTMLCanvasElement;
  if (!ctx) return;

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: structuresDistribution.map(d => d.name),
      datasets: [
        {
          label: "Nombre d'Experts",
          data: structuresDistribution.map(d => d.count),
          backgroundColor: '#6366f1',
          borderRadius: 4
        }
      ]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: { beginAtZero: true, grid: { color: '#e2e8f0', tickBorderDash: [3, 3] } },
        y: { grid: { display: false }, ticks: { font: { size: 11 } } }
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (context) => ` ${context.parsed.x} Experts`
          }
        }
      }
    }
  });
}

function renderExpertsTable(filter: string) {
  const tbody = document.getElementById('experts-table-body');
  if (!tbody) return;

  const filtered = filter === 'all' 
    ? expertsDirectory 
    : expertsDirectory.filter(e => e.type === filter);

  tbody.innerHTML = filtered.map(exp => {
    let typeBadge = '';
    if (exp.type === 'pilotage') {
      typeBadge = '<span class="px-2 py-1 bg-purple-100 text-purple-800 rounded text-xs font-medium">COPIL</span>';
    } else if (exp.type === 'ctc') {
      typeBadge = '<span class="px-2 py-1 bg-amber-100 text-amber-800 rounded text-xs font-medium">CTC</span>';
    } else {
      typeBadge = '<span class="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium">Production (CTM/WG)</span>';
    }

    return `
      <tr class="hover:bg-blue-50 transition-colors cursor-pointer expert-row" data-id="${exp.id}">
        <td class="px-6 py-4">
          <div class="font-bold text-slate-900">${exp.name}</div>
          <div class="font-medium text-slate-700">${exp.id}</div>
          <div class="text-xs text-slate-500">${exp.role}</div>
        </td>
        <td class="px-6 py-4 text-slate-700 font-medium">${exp.structure}</td>
        <td class="px-6 py-4 text-slate-700">${exp.affectation}</td>
        <td class="px-6 py-4 text-center">${typeBadge}</td>
      </tr>
    `;
  }).join('');

  // Add click listeners to rows
  document.querySelectorAll('.expert-row').forEach(row => {
    row.addEventListener('click', (e) => {
      const id = (e.currentTarget as HTMLElement).getAttribute('data-id');
      if (id) openExpertModal(id);
    });
  });
}

function setupExpertFilters() {
  const buttons = document.querySelectorAll('.expert-filter-btn');
  buttons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      // update active state classes
      buttons.forEach(b => {
        b.classList.remove('bg-white', 'shadow-sm', 'text-slate-900');
        b.classList.add('text-slate-600', 'hover:text-slate-900');
      });
      const target = e.currentTarget as HTMLElement;
      target.classList.remove('text-slate-600', 'hover:text-slate-900');
      target.classList.add('bg-white', 'shadow-sm', 'text-slate-900');
      
      const filter = target.getAttribute('data-filter') || 'all';
      renderExpertsTable(filter);
    });
  });
}

function openExpertModal(expertId: string) {
  const expert = expertsDirectory.find(e => e.id === expertId);
  if (!expert) return;

  const modal = document.getElementById('expert-modal');
  const modalContent = document.getElementById('expert-modal-content');
  if (!modal || !modalContent) return;

  // Populate data
  document.getElementById('modal-name')!.textContent = expert.name;
  document.getElementById('modal-role')!.textContent = `${expert.id} - ${expert.role}`;
  document.getElementById('modal-structure')!.textContent = expert.structure;
  document.getElementById('modal-affectation')!.textContent = expert.affectation;
  document.getElementById('modal-bio')!.textContent = expert.bio;

  // Initials
  const initials = expert.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
  document.getElementById('modal-initials')!.textContent = initials;

  // Contributions
  const contributionsList = document.getElementById('modal-contributions');
  if (contributionsList) {
    contributionsList.innerHTML = expert.contributions.map(c => `
      <li class="flex items-start text-sm text-slate-700">
        <i data-lucide="check" class="w-4 h-4 text-green-500 mr-2 mt-0.5 shrink-0"></i>
        <span>${c}</span>
      </li>
    `).join('');
  }

  // Attendance
  const attendanceList = document.getElementById('modal-attendance');
  if (attendanceList) {
    attendanceList.innerHTML = expert.attendance.map(a => `
      <tr>
        <td class="px-4 py-3 text-slate-900 font-medium">${a.session}</td>
        <td class="px-4 py-3 text-slate-500">${a.date}</td>
        <td class="px-4 py-3 text-center">
          ${a.present 
            ? '<span class="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800">Présent</span>'
            : '<span class="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-red-100 text-red-800">Absent</span>'
          }
        </td>
      </tr>
    `).join('');
  }

  // Re-init icons for modal
  createIcons({ icons });

  // Show modal with animation
  modal.classList.remove('hidden');
  // Small delay to allow display:block to apply before opacity transition
  setTimeout(() => {
    modal.classList.remove('opacity-0');
    modal.classList.add('opacity-100');
    modalContent.classList.remove('scale-95');
    modalContent.classList.add('scale-100');
  }, 10);
}

function closeExpertModal() {
  const modal = document.getElementById('expert-modal');
  const modalContent = document.getElementById('expert-modal-content');
  if (!modal || !modalContent) return;

  // Hide with animation
  modal.classList.remove('opacity-100');
  modal.classList.add('opacity-0');
  modalContent.classList.remove('scale-100');
  modalContent.classList.add('scale-95');
  
  setTimeout(() => {
    modal.classList.add('hidden');
  }, 300); // match duration-300
}

document.addEventListener('DOMContentLoaded', () => {
  renderKpiCards();
  renderBarChart();
  renderPieChart();
  renderLineChart();
  renderTimeline();
  renderTable();
  renderStructuresChart();
  renderExpertsTable('all');
  setupExpertFilters();

  // Modal close listeners
  document.getElementById('close-modal')?.addEventListener('click', closeExpertModal);
  document.getElementById('expert-modal')?.addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeExpertModal(); // click outside
  });
});

function renderKpiCards() {
  const container = document.getElementById('kpi-container');
  if (!container) return;

  const kpis = [
    { title: 'Total Experts', value: overviewData.totalExperts, icon: 'users', color: 'text-blue-600', subtitle: 'Répartis en 8 commissions', trend: '+ Élargissement finalisé' },
    { title: 'Normes Ciblées', value: overviewData.totalNorms, icon: 'book-open', color: 'text-indigo-600', subtitle: 'Volume du corpus normatif', trend: '185 NNC en production' },
    { title: 'Phase Actuelle', value: 'Phase 2', icon: 'clock', color: 'text-amber-600', subtitle: 'Rédaction & Adaptation', trend: '16 Juin - 31 Juil 2026' },
    { title: 'Avancement Global', value: '18%', icon: 'trending-up', color: 'text-emerald-600', subtitle: 'Étape 2 (Analyse) en cours', trend: 'En ligne avec les délais' }
  ];

  container.innerHTML = kpis.map(kpi => `
    <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
      <div class="flex items-start justify-between mb-4">
        <div>
          <p class="text-sm font-medium text-slate-500">${kpi.title}</p>
          <h3 class="text-2xl font-bold text-slate-900 mt-1">${kpi.value}</h3>
        </div>
        <div class="p-2 bg-slate-50 rounded-lg">
          <i data-lucide="${kpi.icon}" class="w-5 h-5 ${kpi.color}"></i>
        </div>
      </div>
      <div class="mt-4 pt-4 border-t border-slate-100 flex flex-col space-y-1">
        <span class="text-xs font-medium text-slate-700">${kpi.subtitle}</span>
        <span class="text-xs text-slate-500">${kpi.trend}</span>
      </div>
    </div>
  `).join('');

  createIcons({ icons });
}

function renderBarChart() {
  const ctx = document.getElementById('sc-bar-chart') as HTMLCanvasElement;
  if (!ctx) return;

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: scData.map(d => d.id),
      datasets: [
        {
          label: 'Objectif (Normes)',
          data: scData.map(d => d.normes),
          backgroundColor: '#94a3b8',
          borderRadius: 4
        },
        {
          label: 'Progression (%)',
          data: scData.map(d => d.progress),
          backgroundColor: '#3b82f6',
          borderRadius: 4
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: { grid: { display: false } },
        y: { beginAtZero: true, grid: { color: '#e2e8f0', tickBorderDash: [3, 3] } }
      },
      plugins: {
        legend: { position: 'top', labels: { usePointStyle: true, boxWidth: 6 } }
      }
    }
  });
}

function renderPieChart() {
  const ctx = document.getElementById('experts-pie-chart') as HTMLCanvasElement;
  if (!ctx) return;

  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: expertsOrigin.map(d => d.name),
      datasets: [{
        data: expertsOrigin.map(d => d.value),
        backgroundColor: pieColors,
        borderWidth: 0,
        hoverOffset: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '70%',
      plugins: {
        legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8, font: { size: 11 } } }
      }
    }
  });
}

function renderLineChart() {
  const ctx = document.getElementById('stages-line-chart') as HTMLCanvasElement;
  if (!ctx) return;

  new Chart(ctx, {
    type: 'line',
    data: {
      labels: normsStages.map(d => d.name),
      datasets: [{
        label: 'Normes en cours',
        data: normsStages.map(d => d.count),
        borderColor: '#2563eb',
        backgroundColor: '#2563eb',
        borderWidth: 3,
        pointBackgroundColor: '#fff',
        pointBorderColor: '#2563eb',
        pointBorderWidth: 2,
        pointRadius: 6,
        pointHoverRadius: 8,
        tension: 0.3
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: { grid: { display: false }, ticks: { font: { size: 11 }, maxRotation: 45, minRotation: 45 } },
        y: { beginAtZero: true, grid: { color: '#e2e8f0', tickBorderDash: [3, 3] } }
      },
      plugins: {
        legend: { display: false }
      }
    }
  });
}

function renderTimeline() {
  const container = document.getElementById('timeline-container');
  if (!container) return;

  container.innerHTML = timelinePhases.map((phase, index) => {
    const isLast = index === timelinePhases.length - 1;
    const dotColor = statusColors[phase.status] || 'bg-gray-300';
    
    let actionIcon = '';
    if (phase.status === 'completed') {
      actionIcon = `<i data-lucide="check-circle" class="w-5 h-5 text-green-500"></i>`;
    } else if (phase.status === 'active') {
      actionIcon = `<span class="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-md">En cours</span>`;
    }

    return `
      <div class="flex items-start">
        <div class="flex flex-col items-center mr-4">
          <div class="w-3 h-3 rounded-full mt-1.5 ${dotColor}"></div>
          ${!isLast ? `<div class="w-0.5 h-10 bg-slate-200 my-1"></div>` : ''}
        </div>
        <div>
          <h4 class="text-sm font-bold ${phase.status === 'active' ? 'text-blue-600' : 'text-slate-700'}">
            ${phase.phase} : ${phase.name}
          </h4>
          <p class="text-xs text-slate-500 mt-0.5">${phase.dates}</p>
        </div>
        <div class="ml-auto">
          ${actionIcon}
        </div>
      </div>
    `;
  }).join('');

  createIcons({ icons });
}

function renderTable() {
  const tbody = document.getElementById('table-body');
  if (!tbody) return;

  tbody.innerHTML = scData.map(sc => {
    const barColor = sc.attendance >= 90 ? 'bg-green-500' : 'bg-amber-400';
    
    return `
      <tr class="hover:bg-slate-50 transition-colors">
        <td class="px-6 py-4">
          <div class="font-medium text-slate-900">${sc.id}</div>
          <div class="text-xs text-slate-500">${sc.name}</div>
        </td>
        <td class="px-6 py-4 text-center">${sc.experts}</td>
        <td class="px-6 py-4 text-center">${sc.normes}</td>
        <td class="px-6 py-4">
          <div class="flex items-center justify-center">
            <span class="mr-2 font-medium">${sc.attendance}%</span>
            <div class="w-16 h-2 bg-slate-100 rounded-full overflow-hidden">
              <div class="h-full rounded-full ${barColor}" style="width: ${sc.attendance}%"></div>
            </div>
          </div>
        </td>
        <td class="px-6 py-4 text-center">
          <span class="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-indigo-50 text-indigo-700">
            ${sc.documents} documents
          </span>
        </td>
        <td class="px-6 py-4 text-center">
          <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-50 text-blue-700">
            Étape 2 (25%)
          </span>
        </td>
      </tr>
    `;
  }).join('');
}
